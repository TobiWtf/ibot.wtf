import random, requests, time

bearer: str = "Your Bearer"

def ChangeCords(data) -> None:
    headers: dict = {"Authorization": "Bearer " + bearer}
    with requests.post("https://api.ifunny.mobi/v4/geo", headers=headers, data=data) as client:
        print(client.json())

def RandomLongLat() -> dict:
    data: dict = {"lat": -180 + (180 - -180)*random.random(),
            "lon": -90 + (90 - -90)*random.random()}
    return data

done: bool = False

while not done:
    try:
        cords: dict = RandomLongLat()
        print(cords)
        while True:
            ChangeCords(cords)
            time.sleep(10)
    except KeyboardInterrupt:
        print("(Yes or No)")
        MyInput = input("Do you want to stop the program?: ")
        if MyInput.lower() in ["yes", "ye", "y"]:
            done = True
        else:
            print("Refreshing cordinates...")
