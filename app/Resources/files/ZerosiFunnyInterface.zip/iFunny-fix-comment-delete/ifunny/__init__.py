from ifunny.client import Client
