from ifunny.client._client import Client
