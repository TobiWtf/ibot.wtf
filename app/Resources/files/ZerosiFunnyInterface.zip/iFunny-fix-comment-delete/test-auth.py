import unittest
from tests.auth.client import ClientAuthTest
from tests.auth.user import UserAuthTest
from tests.auth.comment import CommentAuthTest
