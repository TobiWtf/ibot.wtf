import time
import json
import os
import subprocess

#                  Updated 9/8/2020                  #
#        This tool was created by Sergalicious       #
#             Free to Redistribute/Modify            #

version = "1.0.0"

os.system('color')
Green = "\033[0;32m"
Blue = "\033[0;34m"
Reset = "\033[0m"
Red = "\033[0;31m"
Purple = "\033[0;35m"

try:
	#try and set the window width to 190 to fit the basic auth token on the screen properly.
	cmd = 'mode 190,35' 
	os.system(cmd)
except:
	pass

try:
	import requests
except:
	rtvars["errors"].append("Requests module not installed, open a cmd window as administrator and run: '" + Green + "pip install requests" + Red + "'. Then try again")

try:
	req = requests.get("https://s3rg.me/api/v1/updates", timeout = 5)
	if "200" not in str(req):
		print("couldnt check for updates!")
	
	else:
	
		data = req.json()
		
		if data["app_key_grabber"] != version:
			print(Red + "A new Update is avaliable! Get it here: " + Green + "https://s3rg.me/latest/keygetter"+ Reset)
		else:
			print(Green + "You are on the latest version of this app: v" + data["app_key_grabber"] + Reset)
		
	
except:
	print("error while checking for updates!")

bearer = ""
basic = ""
token = ""
user_id = ""
key = ""

rtvars = {"errors":[]}

def genBasicAuth():
	import uuid, base64, hashlib
	clientID = """MsOIJ39Q28"""
	clientSecret = """PTDc3H8a)Vi=UYap"""
	hexstring = str(uuid.uuid4()).encode('utf-8').hex().upper()
	hexId = hexstring + '_' + clientID
	hash_decoded = hexstring + ':' + clientID + ':' + clientSecret
	hash_encoded = hashlib.sha1(hash_decoded.encode('utf-8')).hexdigest()
	return(base64.b64encode(bytes(hexId + ':' + hash_encoded, 'utf-8')).decode())
	
def login(email, password):
	data = {
				'grant_type': 'password',
				'username': email,
				'password': password
			}
	
	print("logging in... ", end = '')
	tries = 0
	while True:
		try:
			req = requests.post("https://api.ifunny.mobi/v4/oauth2/token", headers = {"Authorization":"Basic " + basic}, data = data, timeout = 5) #make login request to ifunny's oauth service
			if "403" in str(req):
				print("Waiting for BasicAuth")
				time.sleep(10)
			else:
				break
			tries += 1
			if tries > 3:
				rtvars["errors"].append("Couldnt log in to ifunny. Last response code was: " + str(req))
				return
		except:
			rtvars["errors"].append("Couldn't connect, Check your internet connection and try again")
			return
	
	if "access_token" in req.text:
		data = req.json()
		print(Green + "Logged in successfully, Retrieving data..." + Reset)
		return data['access_token']
	elif "invalid_grant" in req.text:
		rtvars["errors"].append("your username and/or password is incorrect, try again")
	elif "too_many_user_auths" in req.text:
		rtvars["errors"].append("Too many login attempts, try again after a few mins...")
	else:
		rtvars["errors"].append("Couldnt log in at this time, Maybe ifunny is down?")



if not basic:

	try:
		basic = genBasicAuth() #generate basic auth token, this is the token ifunny uses to associate your accounts with eachother, so generating a new one will simulate logging in from a new device.
	except:
		rtvars["errors"].append("Failed to generate basic auth token, try to install hashlib using the following cmd: '" + Green + "pip install hashlib" + Red + "'")
		

if not bearer and not rtvars["errors"]:
	bearer = login(input("ifunny email: "), input("ifunny password: "))

if not token and not rtvars["errors"] or not user_id and not rtvars["errors"]:
	req = requests.post("https://api.ifunny.mobi/v4/activate_chats", headers = {"Authorization":"Bearer " + bearer}) #activate chats incase the account has not used chats before, usefull if you recently created a new account on the website version of ifunny.
	time.sleep(2) #probably not needed.
	req = requests.get("https://api.ifunny.mobi/v4/account", headers = {"Authorization":"Bearer " + bearer})
	try:
		token = req.json()["data"]["messenger_token"]
	except:
		token = "SendBird messenger token unavaliable"
	user_id = req.json()["data"]["id"]

if not key and not rtvars["errors"]:
	try:
		import websocket
		ws = websocket.create_connection('wss://ws-us-1.sendbird.com/?p=Android&pv=28&sv=3.0.96&ai=AFB3A55B-8275-4C1E-AEA8-309842798187&user_id={}&access_token={}'.format(user_id, token))
		r = ws.recv()
		parsed = json.loads(r[4:])
		if r.startswith("LOGI"):
			key = parsed["key"]
		else:
			rtvars["errors"].append("Didn't recieve login frame, check that your keys were entered correctly.")
	except:
		key = "SendBird Session-Key unavaliable, Make sure you have ran: '" + Green + "pip install websocket_client" + Purple + "' in a cmd window"

if not rtvars["errors"]:
	print(Green + "\nFinished, here are your keys:" + Reset)
	print(Blue + "Basic            : " + Purple + basic)
	print(Blue + "Bearer           : " + Purple + bearer)
	print(Blue + "Messenger_Token  : " + Purple + token)
	print(Blue + "Session-Key      : " + Purple + key + Reset)
	
	print(Green + "Highlight the key you want to copy, and then press enter to copy it to your clipboard."  + Reset)
	print(Red + "\nWarning: Do not share your keys with anyone! To revoke theese keys simply change your ifunny account password!"  + Reset)
else:
	print(Red + "\nThe following errors occoured:" + Reset + "\n")
	for error in rtvars["errors"]:
		print(Red + "\t" + error + Reset + "\n")


input("\npress enter to exit...")